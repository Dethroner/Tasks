                                              MAESTRO CLI QUICK START GUIDELINES
*******************************************************************************************************************************************
***                          These are minimum required instructions to configure and start using Maestro CLI.                          ***
***        Detailed information is contained in Quick Start Guide, Maestro CLI User Guide, and other documents, available by the link:  ***
***                                  https://cloud.epam.com/site/learn/documentation                                                    ***
*******************************************************************************************************************************************

1.      !Make sure you have at least JRE (JDK) version  1.8!

2.      Download installation archive from https://cloud.epam.com/site/develop/maestro_c=l=i/maestro-cli.zip

3.      Unzip the archive to the folder of your choice. !The final path to Maestro CLI should not include spaces!

4.      Start the Maestro CLI:
		
		- Windows:
		  Run the 'windows_console.cmd' executable from the folder.
		
		- *nix OS
		  Add Maestro CLI bin to the PATH environment variable or execute commands from the bin folder as regular scripts.
		  

5.      Use the basic commands to check if Maestro CLI was installed correctly, authorize, and make your first steps in Cloud:

		- Run 'or2help' (without quotes).	If everything is configured correctly, you will receive a list of all commands available in Maestro CLI with their parameters.
          Command example: or2help
	
		- Run 'or2access' and enter your credentials when prompted.
		  Command example: or2access 
	
		- Run 'or2dshape' to find out available instance shapes for your PMC project. Provide your PMC project ID (-p) and desired service region (-r) as its parameters. Choose a shape among the available ones.
          Command example: or2dshape -p SAMPLE_PROJECT -r sample_region

		- Run 'or2dim' to find out available machine images for your project and virtualization region. Provide your PMC project ID (-p) and virtualization region (-r) as parameters. Choose an image among the available ones.
          Command example: or2dim -p SAMPLE_PROJECT -r sample_region
	
		- Run 'or2run' to launch your instance. Provide your PMC project ID (-p), virtualization region (-r), required shape (-s), required machine image (-i), and required number of instances (-c) (optional) as parameters.
          Command example: or2run -p SAMPLE_PROJECT -r sample_region -s SAMPLE_SHAPE -i sample_image

		- Run 'or2din' to confirm your instance has been successfully launched and find out its IP address. Provide your PMC project ID (-p), virtualization region (-r), and instance id (-i) as its parameters.
          Command example: or2din -p SAMPLE_PROJECT -r sample_region -i SAMPLE_INSTANCE
	
		- Use your SSH client to connect to your instance, specifying its private IP.

		- Once you no longer need your instance, run 'or2kill' to terminate it. Provide your PMC project ID (-p), virtualization region (-r), and instance id (-i) as its parameters.
          Command example: or2kill -p SAMPLE_PROJECT -r sample_region -i SAMPLE_INSTANCE
		  
		  

                                        ©1993-2020 EPAM Systems. All rights reserved. For all issues contact SpecialEPM-CSUPConsulting@epam.com
