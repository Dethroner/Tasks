#!/bin/bash

or2adi -t | grep -v "Adding default parameter"
